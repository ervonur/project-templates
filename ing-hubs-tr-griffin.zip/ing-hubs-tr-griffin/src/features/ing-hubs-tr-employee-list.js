import { LitElement, html, css } from "lit";
import { EmployeeServiceMock } from "../mock/employeeService";
import fontawesome from "lit-fontawesome";

const employeeService = new EmployeeServiceMock();

export class IngHubsTrEmployeeList extends LitElement {
    createRenderRoot() {
        return this;
    }

    static styles = [
        fontawesome,
        css`
            #employeeListRoot {
                padding: 12px;
            }
            #employeeListRoot table > thead > tr > th {
                background-color: #e9ecef;
            }
            #employeeListRoot table > thead > tr > th:last-of-type {
                width: 312px;
            }
            #employeeListRoot .btn-details, 
            #employeeListRoot .btn-edit, 
            #employeeListRoot .btn-remove {
                width: 90px;
            }
        `
    ];

    static properties = {
        employeeList: Array
    }

    constructor() {
        super();
        this.employeeList = this.employeeList || [];
    }

    connectedCallback() {
        super.connectedCallback();
        window.dispatchEvent(new Event("loader-show"));
        employeeService.getAll().then(employeeList => {
            this.employeeList = employeeList;
            window.dispatchEvent(new Event("loader-hide"));
        });
    }

    render() {
        return html`
            <style>${IngHubsTrEmployeeList.styles}</style>
            <div id="employeeListRoot">
                <h3 class="border-bottom pb-2 mb-3">Employee List</h3>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email Address</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.employeeList.map(employee => html`
                            <tr>
                                <td>${employee.id}</td>
                                <td>${employee.firstName}</td>
                                <td>${employee.lastName}</td>
                                <td>${employee.email}</td>
                                <td>
                                    <button 
                                        class="btn btn-outline-primary btn-sm btn-details me-2" 
                                        data-id=${employee.id} 
                                        @click=${this.edit}
                                    ><i class="fas fa-file-alt me-2"></i>Details</button>
                                    <button 
                                        class="btn btn-outline-success btn-sm btn-edit me-2" 
                                        data-id=${employee.id} 
                                        @click=${this.edit}
                                    ><i class="fas fa-edit me-2"></i>Edit</button>
                                    <button 
                                        class="btn btn-outline-danger btn-sm btn-remove" 
                                        data-id=${employee.id} 
                                        @click=${this.remove}
                                    ><i class="fas fa-trash-alt me-2"></i>Remove</button>
                                </td>
                            </tr>
                        `)}
                    </tbody>
                </table>
            </div>
        `;
    }

    edit() {
    }

    remove(event) {
        Swal.fire({
            icon: "warning",
            text: "You're about to remove this record. Do you want to continue?",
            showConfirmButton: true,
            showCancelButton: true,
            focusCancel: true
        }).then(result => {
            if (result.isConfirmed) {
                window.dispatchEvent(new Event("loader-show"));
                const employeeId = event.target.getAttribute("data-id");
                if (employeeId) {
                    employeeService.remove(employeeId).then(index => {
                        if (index >= 0) {
                            this.employeeList = this.employeeList.toSpliced(index, 1);
                            window.dispatchEvent(new Event("loader-hide"));
                            Swal.fire({
                                icon: "success",
                                text: "Operation completed successfully!"
                            });
                        }
                    });
                }
            }
        });
    }
}

customElements.define("ing-hubs-tr-employee-list", IngHubsTrEmployeeList);
