import { LitElement, html, css } from "lit";

export class IngHubsTrHome extends LitElement {
    static get styles() {
        return css`
            #homeRoot {
                padding: 12px;
            }
        `;
    }

    createRenderRoot() {
        return this;
    }

    render() {
        return html`
            <style>${IngHubsTrHome.styles}</style>
            <ing-hubs-tr-carousel></ing-hubs-tr-carousel>
            <div class="row" style="padding: 12px;">
                <div class="col-4">
                    <ing-hubs-tr-card
                        header="Header"
                        title="Light card title"
                        text="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
                    ></ing-hubs-tr-card>
                </div>
                <div class="col-4">
                    <ing-hubs-tr-card
                        header="Header"
                        title="Light card title"
                        text="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
                    ></ing-hubs-tr-card>
                </div>
                <div class="col-4">
                    <ing-hubs-tr-card
                        header="Header"
                        title="Light card title"
                        text="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
                    ></ing-hubs-tr-card>
                </div>
            </div>
        `;
    }
}

customElements.define("ing-hubs-tr-home", IngHubsTrHome);
