import { LitElement, html, css } from "lit";
import fontawesome from "lit-fontawesome";

export class IngHubsTrEmployee extends LitElement {
    createRenderRoot() {
        return this;
    }

    static styles = [
        fontawesome,
        css`
            #employeeRoot {
                padding: 12px;
            }
            .form-control {
                width: 45%;
            }
        `
    ];

    static properties = {
        firstName: String,
        firstNameFeedback: String,
        lastName: String,
        lastNameFeedback: String,
        email: String,
        emailFeedback: String,
        phone: String,
        phoneFeedback: String
    };

    constructor() {
        super();
        this.firstName = "";
        this.firstNameFeedback = "";
        this.lastName = "";
        this.lastNameFeedback = "";
        this.email = "";
        this.emailFeedback = "";
        this.phone = "";
        this.phoneFeedback = "";
    }
    
    render() {
        return html`
            <style>${IngHubsTrEmployee.styles}</style>
            <div id="employeeRoot">
                <h3 class="border-bottom pb-2">Employee</h3>
                <form id="employeeForm">
                    <div class="mb-3">
                        <label for="firstNameInput" class="form-label">First Name</label>
                        <input type="text" class="form-control ${this.firstNameFeedback ? 'is-invalid' : ''}" id="firstNameInput" maxlength="100" autocomplete="off" spellcheck="false" @change=${this.firstNameChange}>
                        <div class="invalid-feedback" id="firstNameFeedback">${this.firstNameFeedback}</div>
                    </div>
                    <div class="mb-3">
                        <label for="lastNameInput" class="form-label">Last Name</label>
                        <input type="text" class="form-control ${this.lastNameFeedback ? 'is-invalid' : ''}" id="lastNameInput" maxlength="100" autocomplete="off" spellcheck="false" @change=${this.lastNameChange}>
                        <div class="invalid-feedback" id="lastNameFeedback">${this.lastNameFeedback}</div>
                    </div>
                    <div class="mb-3">
                        <label for="emailInput" class="form-label">Email Address</label>
                        <input type="email" class="form-control ${this.emailFeedback ? 'is-invalid' : ''}" id="emailInput" maxlength="100" autocomplete="off" spellcheck="false" @change=${this.emailChange}>
                        <div class="invalid-feedback" id="emailFeedback">${this.emailFeedback}</div>
                    </div>
                    <div class="mb-3">
                        <label for="phoneInput" class="form-label">Phone Number</label>
                        <input type="text" class="form-control ${this.phoneFeedback ? 'is-invalid' : ''}" id="phoneInput" maxlength="13" autocomplete="off" spellcheck="false" @change=${this.phoneChange}>
                        <div class="invalid-feedback" id="phoneFeedback">${this.phoneFeedback}</div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="saveButton" @click=${this.save}><i class="fas fa-check me-2"></i>Save</button>
                </form>
            </div>
        `;
    }

    firstNameChange(event) {
        this.firstName = event.target.value.trim();
        this.validateFirstName();
    }

    lastNameChange(event) {
        this.lastName = event.target.value.trim();
        this.validateLastName();
    }

    emailChange(event) {
        this.email = event.target.value.trim();
        this.validateEmail();
    }

    phoneChange(event) {
        this.phone = event.target.value.trim();
        this.validatePhone();
    }

    save(event) {
        event.preventDefault();

        this.validateFirstName();
        this.validateLastName();
        this.validateEmail();
        this.validatePhone();

        if (this.isValidForm()) {
            // todo: add new employee here...
        } else {
            this.focusOnInvalidInput();
        }
    }

    validateFirstName() {
        this.firstNameFeedback = "";
        if (!this.firstName.length) {
            this.firstNameFeedback = "Please enter the first name.";
        }
    }

    validateLastName() {
        this.lastNameFeedback = "";
        if (!this.lastName.length) {
            this.lastNameFeedback = "Please enter the last name.";
        }
    }

    validateEmail() {
        this.emailFeedback = "";
        if (!this.email.length) {
            this.emailFeedback = "Please enter the email address.";
        }
    }

    validatePhone() {
        this.phoneFeedback = "";
        if (!this.phone.length) {
            this.phoneFeedback = "Please enter the phone number.";
        }
    }

    isValidForm() {
        return document.querySelectorAll("#employeeForm .is-invalid").length === 0;
    }

    focusOnInvalidInput() {
        const element = document.querySelector("#employeeForm .is-invalid");
        if (element) {
            element.focus();
        }
    }
}

customElements.define("ing-hubs-tr-employee", IngHubsTrEmployee);
