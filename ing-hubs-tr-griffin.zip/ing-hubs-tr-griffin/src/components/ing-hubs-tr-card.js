import { LitElement, html } from "lit";

export class IngHubsTrCard extends LitElement {
    createRenderRoot() {
        return this;
    }

    static get properties() {
        return {
            header: String,
            title: String,
            text: String
        };
    }

    render() {
        return html`
            <div class="card text-bg-light mb-3">
                <div class="card-header">${this.header}</div>
                <div class="card-body">
                    <h5 class="card-title">${this.title}</h5>
                    <p class="card-text">${this.text}</p>
                </div>
            </div>
        `;
    }
}

customElements.define("ing-hubs-tr-card", IngHubsTrCard);
