import { LitElement, css, html } from "lit";

export class IngHubsTrLoader extends LitElement {
    static get styles() {
        return css`
            #loader {
                cursor: wait;
                background: rgba(0,0,0,.4);
                position: fixed; 
                top: 0px; 
                left: 0px; 
                width: 100%;
                height: 100%;
                z-index: 1;
            }
            #loader[hidden] {
                display: none;
            }
        `;
    }

    static get properties() {
        return {
            isVisible: Boolean
        };
    }

    constructor() {
        super();
        this.isVisible = false;
    }

    connectedCallback() {
        super.connectedCallback();
        window.addEventListener("loader-show", () => this.isVisible = true );
        window.addEventListener("loader-hide", () => this.isVisible = false );
    }

    render() {
        return html`
            <div id="loader" ?hidden=${!this.isVisible}></div>
        `;
    }
}

customElements.define("ing-hubs-tr-loader", IngHubsTrLoader);
