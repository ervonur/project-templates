import { LitElement, css, html } from "lit";

export class IngHubsTrNavbar extends LitElement {
    createRenderRoot() {
        return this;
    }

    static styles = css`
        .navbar {
            background-color: #ff6600 !important;
        }
        .navbar-brand {
            display: flex;
            align-items: center;
        }
    `;

    render() {
        return html`
            <style>${IngHubsTrNavbar.styles}</style>
            <nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/">
                        <img class="me-3" src="./images/logo.png" width="40">
                        <span>ING Hubs Türkiye</span>
                    </a>
                </div>
            </nav>
        `;
    }
}

customElements.define("ing-hubs-tr-navbar", IngHubsTrNavbar);
