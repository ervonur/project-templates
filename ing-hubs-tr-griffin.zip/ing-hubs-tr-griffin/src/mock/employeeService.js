const employeeList = [
    { id: "1001", firstName: "Employee", lastName:"01", email: "emp01@mail.com", phone: "111 111 11 01" },
    { id: "1002", firstName: "Employee", lastName:"02", email: "emp02@mail.com", phone: "111 111 11 02" },
    { id: "1003", firstName: "Employee", lastName:"03", email: "emp03@mail.com", phone: "111 111 11 03" },
    { id: "1004", firstName: "Employee", lastName:"04", email: "emp04@mail.com", phone: "111 111 11 04" },
    { id: "1005", firstName: "Employee", lastName:"05", email: "emp05@mail.com", phone: "111 111 11 05" },
    { id: "1006", firstName: "Employee", lastName:"06", email: "emp06@mail.com", phone: "111 111 11 06" },
    { id: "1007", firstName: "Employee", lastName:"07", email: "emp07@mail.com", phone: "111 111 11 07" },
    { id: "1008", firstName: "Employee", lastName:"08", email: "emp08@mail.com", phone: "111 111 11 08" },
    { id: "1009", firstName: "Employee", lastName:"09", email: "emp09@mail.com", phone: "111 111 11 09" },
    { id: "1010", firstName: "Employee", lastName:"10", email: "emp10@mail.com", phone: "111 111 11 10" },
    { id: "1011", firstName: "Employee", lastName:"11", email: "emp11@mail.com", phone: "111 111 11 11" },
    { id: "1012", firstName: "Employee", lastName:"12", email: "emp12@mail.com", phone: "111 111 11 12" },
    { id: "1013", firstName: "Employee", lastName:"13", email: "emp13@mail.com", phone: "111 111 11 13" },
    { id: "1014", firstName: "Employee", lastName:"14", email: "emp14@mail.com", phone: "111 111 11 14" },
    { id: "1015", firstName: "Employee", lastName:"15", email: "emp15@mail.com", phone: "111 111 11 15" },
    { id: "1016", firstName: "Employee", lastName:"16", email: "emp16@mail.com", phone: "111 111 11 16" },
    { id: "1017", firstName: "Employee", lastName:"17", email: "emp17@mail.com", phone: "111 111 11 17" },
    { id: "1018", firstName: "Employee", lastName:"18", email: "emp18@mail.com", phone: "111 111 11 18" },
    { id: "1019", firstName: "Employee", lastName:"19", email: "emp19@mail.com", phone: "111 111 11 19" },
    { id: "1020", firstName: "Employee", lastName:"20", email: "emp20@mail.com", phone: "111 111 11 20" },
    { id: "1021", firstName: "Employee", lastName:"21", email: "emp21@mail.com", phone: "111 111 11 21" },
    { id: "1022", firstName: "Employee", lastName:"22", email: "emp22@mail.com", phone: "111 111 11 22" },
    { id: "1023", firstName: "Employee", lastName:"23", email: "emp23@mail.com", phone: "111 111 11 23" },
    { id: "1024", firstName: "Employee", lastName:"24", email: "emp24@mail.com", phone: "111 111 11 24" },
    { id: "1025", firstName: "Employee", lastName:"25", email: "emp25@mail.com", phone: "111 111 11 25" }
];

export class EmployeeServiceMock {
    seed() {
        this.getAll().then(data => {
            if (!Array.isArray(data)) {
                data = employeeList;
                sessionStorage.setItem("employeeList", JSON.stringify(data));
            }
        });
    }

    getAll() {
        return new Promise(success => {
            const timeoutId = setTimeout(() => {
                success(JSON.parse(sessionStorage.getItem("employeeList")));
                clearTimeout(timeoutId);
            }, 1000);
        });
    }

    remove(id) {
        return new Promise(success => {
            const timeoutId = setTimeout(() => {
                const data = JSON.parse(sessionStorage.getItem("employeeList"));
                const index = data.map(employee => employee.id).indexOf(id);
                if (index >= 0) {
                    data.splice(index, 1);
                    sessionStorage.setItem("employeeList", JSON.stringify(data));
                }
                success(index);
                clearTimeout(timeoutId);
            }, 1000);
        });
    }
}
