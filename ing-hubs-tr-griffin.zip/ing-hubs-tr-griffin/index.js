import { Router } from "@vaadin/router";
import { EmployeeServiceMock } from "./src/mock/employeeService";

const routes = [
    { path: "/", component: "ing-hubs-tr-home" },
    { path: "/employee", component: "ing-hubs-tr-employee" },
    { path: "/employees", component: "ing-hubs-tr-employee-list" },
    { path: "(.*)", component: "ing-hubs-tr-home" }
];

window.addEventListener("load", () => {
    new EmployeeServiceMock().seed();
    new Router(document.querySelector("#outlet")).setRoutes(routes);
});

document.addEventListener("click", (event) => {
    if (event.target.nodeName !== "ING-HUBS-TR-MENU") {
        window.dispatchEvent(new CustomEvent("reset-active-menu-items"));
    }
});
