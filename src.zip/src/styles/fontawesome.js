import fontawesome from "lit-fontawesome";

export const Fontawesome = fontawesome;
