export const foo = "foo";
export const bar = "bar";
