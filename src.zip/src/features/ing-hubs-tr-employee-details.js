import { LitElement, html } from "lit";

export class IngHubsTrEmployeeDetails extends LitElement {
    render() {
        return html`
            <div>Employee Details</div>
        `;
    }
}

customElements.define("ing-hubs-tr-employee-details", IngHubsTrEmployeeDetails);
